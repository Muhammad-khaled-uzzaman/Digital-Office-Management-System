/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digital_office_management_system;

/**
 *
 * @author USER
 */
public class Digital_Office_Management_System {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        AdminOrStaff_form adminOrStaff = new AdminOrStaff_form();
        adminOrStaff.setVisible(true);
    }
    
}
